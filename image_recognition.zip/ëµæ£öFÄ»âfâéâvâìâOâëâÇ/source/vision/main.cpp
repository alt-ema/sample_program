//**************************************************************************
//���C�����[�`��
//**************************************************************************

//using STL
#include <string>

//using OpenCV
#include "opencv2\opencv.hpp"
#include "opencv_lib.hpp"

//using shlwapi
#include <shlwapi.h>

//using CString
#include <atlstr.h>

//using Machine Learning
#include "classify.h"
#include "AdaBoost.h"
#include "SVM.h"

//using DataSet
#include "dataSet.h"

//using Feature
#include "feature.h"
#include "HLAC.h"
#include "ImprovedLBP.h"
#include "LBP.h"
#include "proposed.h"
#include "RotatedLBP.h"
#include "UniformLBP.h"

//other
#include "define.h"

#pragma comment(lib, "ShLwApi.Lib")

using namespace std;
using namespace cv;

//**************************************************************************
//���C�����[�`��
//**************************************************************************
int main(int argc, char* argv[])
{

	CDataSet* dataSet;			//�f�[�^�Z�b�g�C���X�^���X
	CFeature* feature;			//�����ʃC���X�^���X
	CClassify_recog* recog;		//�F���N���X�C���X�^���X
	CClassify_train* train;		//�w�K�N���X�C���X�^���X

	//error check
	if (argc == 1) {

		cout << "usage: vision.exe [OPTION]" << endl;
		return -1;

	}

	//train section
	if (strcmp(argv[1], "--train") == 0) {
		//error check
		if (argc != 5) {

			cout << "usage: vision.exe --train [FEATURE] [LEARNING] [FILENAME]" << endl;
			return -1;

		}

		//dataset �C���X�^���X��
		dataSet = new CDataSet(POSITIVE_LIGHT_DIR, NEGATIVE_LIRHT_DIR);

		//error check
		if (dataSet->negativeSample.size() == 0 || dataSet->positiveSample.size() == 0) {
		
			MessageBox(NULL, TEXT("dataSet error"), TEXT("error"), MB_OK | MB_ICONINFORMATION);
			return -1;

		}
		
		//feature �C���X�^���X��
		if (string(argv[2]) == "--HLAC")			//HLAC feature
			feature = new CHLACfeature();

		else if (string(argv[2]) == "--LBP")		//LBP feature
			feature = new CLBPfeature();

		else if (string(argv[2]) == "--ILBP")		//Improved LBP feature
			feature = new CImprovedLBP();

		else if (string(argv[2]) == "--RLBP")		//Rotated LBP feature
			feature = new CRotatedLBP();

		else if (string(argv[2]) == "--ULBP1")		//1st Uniform LBP feature
			feature = new CUniformLBP1();

		else if (string(argv[2]) == "--ULBP2")		//2nd Uniform LBP feature
			feature = new CUniformLBP2();

		else if (string(argv[2]) == "--ULBP3")		//3rd Uniform LBP feature
			feature = new CUniformLBP3();

		else if (string(argv[2]) == "--PROPOSED")	//proposed method
			feature = new CProposedfeature();

		else {

			cout << "option error : [FEATURE]" << endl;
			return -1;

		}

		//classify �C���X�^���X��
		if (string(argv[3]) == "--SVM")
			train = new CSVM_train(dataSet, feature, string(argv[4]));		//use SVM

		else if (string(argv[3]) == "--Boost")
			train = new CBoost_train(dataSet, feature, string(argv[4]));	//use Boosting

		else {

			cout << "option error : [LEARNING]" << endl;
			return -1;

		}

		//run
		train->run();

	}
	//recog section
	else if (strcmp(argv[1], "--recog") == 0){
		//error check
		if (argc != 5) {

			cout << "usage: vision.exe --recog [FEATURE] [IMAGE] [FILENAME]" << endl;
			return -1;

		}

		//error check(file input check)
		CString tmp = argv[4];
		if (PathFileExists(tmp) == 0){

			MessageBox(NULL, TEXT("file not exist."), TEXT("error"), MB_OK | MB_ICONINFORMATION);
			return -1;

		}
		

		//feature �C���X�^���X��
		if (string(argv[2]) == "--HLAC")			//HLAC feature
			feature = new CHLACfeature();

		else if (string(argv[2]) == "--LBP")		//LBP feature
			feature = new CLBPfeature();

		else if (string(argv[2]) == "--ILBP")		//Improved LBP feature
			feature = new CImprovedLBP();

		else if (string(argv[2]) == "--RLBP")		//Rotated LBP feature
			feature = new CRotatedLBP();

		else if (string(argv[2]) == "--ULBP1")		//1st Uniform LBP feature
			feature = new CUniformLBP1();

		else if (string(argv[2]) == "--ULBP2")		//2nd Uniform LBP feature
			feature = new CUniformLBP2();

		else if (string(argv[2]) == "--ULBP3")		//3rd Uniform LBP feature
			feature = new CUniformLBP3();

		else if (string(argv[2]) == "--PROPOSED")	//proposed method
			feature = new CProposedfeature();

		else {

			cout << "option error : [FEATURE]" << endl;
			return -1;

		}

		//classify �C���X�^���X��
		if (strstr(argv[4], "SVM") != NULL)
			recog = new CSVM_recog(string(argv[3]), feature, string(argv[4]));		//use SVM

		else if (strstr(argv[4], "BOOST") != NULL)
			recog = new CBoost_recog(string(argv[3]), feature, string(argv[4]));	//use Boosting

		else {

			cout << "option error : [FILENAME]" << endl;
			return -1;

		}

		//run
		recog->run();

	}
	//other
	else {
		//not option
		cout << "option error : [OPTION]" << endl;
		return -1;

	}

	return 0;
}