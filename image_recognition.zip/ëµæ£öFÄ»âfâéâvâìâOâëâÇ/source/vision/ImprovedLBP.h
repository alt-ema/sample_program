//**************************************************************************
//Improved Local Binary Pattern
//dimension : 256
//**************************************************************************

#pragma once

#include "feature.h"

using namespace std;
using namespace cv;

//**************************************************************************
//�R���X�^���g���X�g
//**************************************************************************
static const int ILBP_DIMENSION = 256;

//**************************************************************************
//improvedLBP�N���X
//**************************************************************************
class CImprovedLBP : public CFeature
{

public:

	CImprovedLBP()
		: CFeature(ILBP_DIMENSION)
	{
	
		cout << "������feature type : improved LBP������" << endl;

	}

	vector< float > extract(Mat img);

};
