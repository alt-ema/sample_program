//**************************************************************************
//Local Binary Pattern
//dimension : 256
//**************************************************************************

#pragma once

#include "feature.h"

using namespace std;
using namespace cv;

//**************************************************************************
//�R���X�^���g���X�g
//**************************************************************************
static const int LBP_DIMENSION = 256;

//**************************************************************************
//LBP�N���X
//**************************************************************************
class CLBPfeature : public CFeature
{

public:

	CLBPfeature()
		: CFeature(LBP_DIMENSION)
	{
	
		cout << "������feature type : LBP������" << endl;

	}

	vector< float > extract(Mat img);

};
