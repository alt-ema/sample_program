//**************************************************************************
//Rotated Local Binary Pattern
//dimension : 256
//**************************************************************************

#pragma once

#include "feature.h"

using namespace std;
using namespace cv;

//**************************************************************************
//�R���X�^���g���X�g
//**************************************************************************
static const int RLBP_DIMENSION = 256;

//**************************************************************************
//RotatedLBP�N���X
//**************************************************************************
class CRotatedLBP : public CFeature
{

public:

	CRotatedLBP()
		: CFeature(RLBP_DIMENSION)
	{
	
		cout << "������feature type : rotated LBP������" << endl;

	}

	vector< float > extract(Mat img);

};
