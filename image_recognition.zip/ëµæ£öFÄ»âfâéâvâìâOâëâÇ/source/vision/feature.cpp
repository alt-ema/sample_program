//**************************************************************************
//�����ʎZ�o�N���X
//**************************************************************************

#include "feature.h"

//**************************************************************************
//�����ʂ̐��K��
//vector< float >	: ������
//return			: ���K����
//**************************************************************************
vector< float > CFeature::normalize(vector< float > sample)
{

	float sum = 0;

	for (unsigned int i = 0; i < sample.size(); i++)
		sum += sample[i];

	for (unsigned int i = 0; i < sample.size(); i++)
		sample[i] /= sum;

	return sample;

}
