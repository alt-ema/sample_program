//**************************************************************************
//Rotated Local BInary Pattern
//dimension : 256
//**************************************************************************

#include "RotatedLBP.h"

//**************************************************************************
//��]�s�� LBP �����ʂ̎Z�o
//Mat		: �Z�o�摜
//return	: ������
//**************************************************************************
vector< float > CRotatedLBP::extract(Mat img)
{

	static bool is_calc_lut = false;
	static unsigned char lut[RLBP_DIMENSION];
	vector<float> feature(RLBP_DIMENSION, 0);

	if (is_calc_lut == false) {

		is_calc_lut = true;

		for (int val = 0; val < (sizeof(lut) / sizeof(lut[0])); val++) {

			// val����rotate -> ��ԏ������l���̗p
			unsigned int val_tmp = (unsigned int)val;
			unsigned int val_min = UINT_MAX;

			for (int r = 0; r < 8; r++) {

				if (val_tmp < val_min) {

					val_min = val_tmp;

				}

				val_tmp = (val_tmp >> 1) | ((val_tmp & 0x1U) << 7);

			}

			lut[val] = (unsigned char)val_min;

		}

	}

	if (!img.empty()) {

		int r = img.rows - 1;	//�s
		int c = img.cols - 1;	//��

		for (int y = 1; y < r; y++) {

			for (int x = 1; x < c; x++) {

				unsigned char p_src[] = {
					img.at<unsigned char>(y, x - 1)
					, img.at<unsigned char>(y + 1, x - 1)
					, img.at<unsigned char>(y + 1, x)
					, img.at<unsigned char>(y + 1, x + 1)
					, img.at<unsigned char>(y, x + 1)
					, img.at<unsigned char>(y - 1, x + 1)
					, img.at<unsigned char>(y - 1, x)
					, img.at<unsigned char>(y - 1, x - 1)
				};

				unsigned char p = img.at<unsigned char>(y, x);

				int out_tmp = (p_src[7] <= p) ? 0 : (1 << 7);
				out_tmp += (p_src[6] <= p) ? 0 : (1 << 6);
				out_tmp += (p_src[5] <= p) ? 0 : (1 << 5);
				out_tmp += (p_src[4] <= p) ? 0 : (1 << 4);
				out_tmp += (p_src[3] <= p) ? 0 : (1 << 3);
				out_tmp += (p_src[2] <= p) ? 0 : (1 << 2);
				out_tmp += (p_src[1] <= p) ? 0 : (1 << 1);
				out_tmp += (p_src[0] <= p) ? 0 : 1;

				feature[lut[out_tmp]]++;

			}

		}

	}

	return feature;

}
