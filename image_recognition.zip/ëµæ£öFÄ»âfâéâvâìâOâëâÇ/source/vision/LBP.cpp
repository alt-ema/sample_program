//**************************************************************************
//Local BInary Pattern
//dimension : 256
//**************************************************************************

#include "LBP.h"

//**************************************************************************
//LBP �����ʂ̎Z�o
//Mat		: �Z�o�摜
//return	: ������
//**************************************************************************
vector< float > CLBPfeature::extract(Mat img)
{

	vector<float> feature(LBP_DIMENSION, 0);

	if (!img.empty()) {

		int r = img.rows - 1;	//�s
		int c = img.cols - 1;	//��

		for (int y = 1; y < r; y++) {

			for (int x = 1; x < c; x++) {

				unsigned char p_src[] = {
					img.at<unsigned char>(y, x - 1)
					, img.at<unsigned char>(y + 1, x - 1)
					, img.at<unsigned char>(y + 1, x)
					, img.at<unsigned char>(y + 1, x + 1)
					, img.at<unsigned char>(y, x + 1)
					, img.at<unsigned char>(y - 1, x + 1)
					, img.at<unsigned char>(y - 1, x)
					, img.at<unsigned char>(y - 1, x - 1)
				};

				unsigned char p = img.at<unsigned char>(y, x);

				int out_tmp = (p_src[7] <= p) ? 0 : (1 << 7);
				out_tmp += (p_src[6] <= p) ? 0 : (1 << 6);
				out_tmp += (p_src[5] <= p) ? 0 : (1 << 5);
				out_tmp += (p_src[4] <= p) ? 0 : (1 << 4);
				out_tmp += (p_src[3] <= p) ? 0 : (1 << 3);
				out_tmp += (p_src[2] <= p) ? 0 : (1 << 2);
				out_tmp += (p_src[1] <= p) ? 0 : (1 << 1);
				out_tmp += (p_src[0] <= p) ? 0 : 1;

				feature[out_tmp]++;

			}

		}

	}

	return feature;

}
