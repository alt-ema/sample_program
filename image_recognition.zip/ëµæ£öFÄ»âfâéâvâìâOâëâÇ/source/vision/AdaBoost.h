//**************************************************************************
//AdaBoost
//**************************************************************************

#pragma once

#include "classify.h"

using namespace std;
using namespace cv;

//**************************************************************************
//AdaBoost�w�K�N���X
//**************************************************************************
class CBoost_train : public CClassify_train
{

public:

	CBoost_train(CDataSet* dataSet, CFeature* feature, string fileName);

	void run();

protected:

	CvBoost boost;
	CvBoostParams params;

};

//**************************************************************************
//AdaBoost�F���N���X
//**************************************************************************
class CBoost_recog : public CClassify_recog
{

public:

	CBoost_recog(string imageFile, CFeature* feature, string fileName);

	void run();

protected:

	CvBoost boost;
	CvBoostParams params;

};
