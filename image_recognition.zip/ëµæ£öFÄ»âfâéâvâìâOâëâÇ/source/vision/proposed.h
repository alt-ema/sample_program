//**************************************************************************
//��Ď�@
//dimension : 256
//**************************************************************************

#pragma once

#include "feature.h"

using namespace std;
using namespace cv;

//**************************************************************************
//�R���X�^���g���X�g
//**************************************************************************
static const int PROPOSED_DIMENSION = 256;

//**************************************************************************
//��Ď�@�N���X
//**************************************************************************
class CProposedfeature : public CFeature
{

public:

	CProposedfeature()
		: CFeature(PROPOSED_DIMENSION)
	{
	
		cout << "������feature type : proposed������" << endl;

	}

	vector< float > extract(Mat img);

};
