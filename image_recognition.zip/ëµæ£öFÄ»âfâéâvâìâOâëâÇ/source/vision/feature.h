//**************************************************************************
//�����ʎZ�o�N���X
//**************************************************************************

#pragma once

#include <vector>
#include "opencv2\opencv.hpp"
#include "opencv_lib.hpp"

using namespace std;
using namespace cv;

//**************************************************************************
//�����ʎZ�o�N���X
//**************************************************************************
class CFeature
{

public:

	CFeature(int dimension)
	{
	
		cout << "CFeature::CFeature" << " : start" << endl;
		this->dimension = dimension;
		cout << "CFeature::CFeature" << " : end" << endl;

	}

	int getDimension(){ return dimension; }
	vector< float > normalize(vector< float > sample);
	virtual vector< float > extract(Mat img) = 0;

protected:

	int dimension;

};
