//**************************************************************************
//Uniform Local Binary Pattern
//1dim uniform LBP dimension : 59
//2dim uniform LBP dimension : 243
//3dim uniform LBP dimension : 555
//**************************************************************************

#include "UniformLBP.h"

//**************************************************************************
//1�̗����Ă���bit�����J�E���g���� for Uniform LBP only
//int	: ����l
//int	: ����
//**************************************************************************
int count1(int s)
{

	int c = 0;

	do {

		if (s % 2 == 1)
			c++;

		s = s >> 1;

	} while (s != 0);

	return c;

}

//**************************************************************************
//1����uniform LBP �����ʂ̎Z�o
//Mat		: �Z�o�摜
//return	: ������
//**************************************************************************
vector< float > CUniformLBP1::extract(Mat img)
{

	vector<float> feature(ULBP1_DIMENSION, 0);

	if (!img.empty()) {

		int r = img.rows - 1;
		int c = img.cols - 1;

		for (int y = 1; y < r; y++) {

			for (int x = 1; x < c; x++) {

				unsigned char p_src[] = {
					img.at<unsigned char>(y, x - 1)
					, img.at<unsigned char>(y + 1, x - 1)
					, img.at<unsigned char>(y + 1, x)
					, img.at<unsigned char>(y + 1, x + 1)
					, img.at<unsigned char>(y, x + 1)
					, img.at<unsigned char>(y - 1, x + 1)
					, img.at<unsigned char>(y - 1, x)
					, img.at<unsigned char>(y - 1, x - 1)
				};

				unsigned char p = img.at<unsigned char>(y, x);

				int out_tmp = (p_src[7] <= p) ? 0 : (1 << 7);
				out_tmp += (p_src[6] <= p) ? 0 : (1 << 6);
				out_tmp += (p_src[5] <= p) ? 0 : (1 << 5);
				out_tmp += (p_src[4] <= p) ? 0 : (1 << 4);
				out_tmp += (p_src[3] <= p) ? 0 : (1 << 3);
				out_tmp += (p_src[2] <= p) ? 0 : (1 << 2);
				out_tmp += (p_src[1] <= p) ? 0 : (1 << 1);
				out_tmp += (p_src[0] <= p) ? 0 : 1;

				int i = 0;
				int c = count1(out_tmp);

				if (c == 0) {

					feature[7 * 8]++;
					continue;

				}

				if (c == 8) {

					feature[7 * 8 + 1]++;
					continue;

				}

				for (;;) {

					if (((out_tmp & 1) == 1 && (out_tmp & (1 << 7)) >> 7 == 1)
						|| (out_tmp & 1) == 0) {

						out_tmp = out_tmp >> 1 | (out_tmp & 1) << 7;
						i++;

					}

					else if ((out_tmp & 1) == 1 && (out_tmp & (1 << 7)) >> 7 == 0)
						break;

				}

				out_tmp = out_tmp >> c;

				if (out_tmp == 0)
					feature[(c - 1) * 8 + i]++;

				else
					feature[7 * 8 + 2]++;

			}

		}

	}

	return feature;

}

//**************************************************************************
//2����uniform LBP �����ʂ̎Z�o
//Mat		: �Z�o�摜
//return	: ������
//**************************************************************************
vector< float > CUniformLBP2::extract(Mat img)
{

	vector<float> feature(ULBP2_DIMENSION, 0);

	if (!img.empty()) {

		int r = img.rows - 2;
		int c = img.cols - 2;

		for (int y = 2; y < r; y++) {

			for (int x = 2; x < c; x++) {

				unsigned char p_src[] = {
					img.at<unsigned char>(y - 1, x - 2)
					, img.at<unsigned char>(y, x - 2)
					, img.at<unsigned char>(y + 1, x - 2)
					, img.at<unsigned char>(y + 2, x - 2)
					, img.at<unsigned char>(y + 2, x - 1)
					, img.at<unsigned char>(y + 2, x)
					, img.at<unsigned char>(y + 2, x + 1)
					, img.at<unsigned char>(y + 2, x + 2)
					, img.at<unsigned char>(y + 1, x + 2)
					, img.at<unsigned char>(y, x + 2)
					, img.at<unsigned char>(y - 1, x + 2)
					, img.at<unsigned char>(y - 2, x + 2)
					, img.at<unsigned char>(y - 2, x + 1)
					, img.at<unsigned char>(y - 2, x)
					, img.at<unsigned char>(y - 2, x - 1)
					, img.at<unsigned char>(y - 2, x - 2)
				};

				unsigned char p = img.at<unsigned char>(y, x);

				int out_tmp = 0;

				for (int i = 0; i < 16; i++) {

					out_tmp += (p_src[i] <= p) ? 0 : (1 << i);

				}

				int i = 0;
				int c = count1(out_tmp);

				if (c == 0) {

					feature[15 * 16]++;
					continue;

				}

				if (c == 16) {

					feature[15 * 16 + 1]++;
					continue;

				}

				for (;;) {

					if (((out_tmp & 1) == 1 && (out_tmp & (1 << 15)) >> 15 == 1)
						|| (out_tmp & 1) == 0) {

						out_tmp = out_tmp >> 1 | (out_tmp & 1) << 15;
						i++;

					}

					else if ((out_tmp & 1) == 1 && (out_tmp & (1 << 15)) >> 15 == 0)
						break;

				}

				out_tmp = out_tmp >> c;

				if (out_tmp == 0)
					feature[(c - 1) * 16 + i]++;

				else
					feature[15 * 16 + 2]++;

			}

		}

	}

	return feature;

}

//**************************************************************************
//3����uniform LBP �����ʂ̎Z�o
//Mat		: �Z�o�摜
//return	: ������
//**************************************************************************
vector< float > CUniformLBP3::extract(Mat img)
{

	vector<float> feature(ULBP3_DIMENSION, 0);

	if (!img.empty()) {

		int r = img.rows - 3;
		int c = img.cols - 3;

		for (int y = 3; y < r; y++) {

			for (int x = 3; x < c; x++) {

				unsigned char p_src[] = {
					img.at<unsigned char>(y - 2, x - 3)
					, img.at<unsigned char>(y - 1, x - 3)
					, img.at<unsigned char>(y, x - 3)
					, img.at<unsigned char>(y + 1, x - 3)
					, img.at<unsigned char>(y + 2, x - 3)
					, img.at<unsigned char>(y + 3, x - 3)
					, img.at<unsigned char>(y + 3, x - 2)
					, img.at<unsigned char>(y + 3, x - 1)
					, img.at<unsigned char>(y + 3, x)
					, img.at<unsigned char>(y + 3, x + 1)
					, img.at<unsigned char>(y + 3, x + 2)
					, img.at<unsigned char>(y + 3, x + 3)
					, img.at<unsigned char>(y + 2, x + 3)
					, img.at<unsigned char>(y + 1, x + 3)
					, img.at<unsigned char>(y, x + 3)
					, img.at<unsigned char>(y - 1, x + 3)
					, img.at<unsigned char>(y - 2, x + 3)
					, img.at<unsigned char>(y - 3, x + 3)
					, img.at<unsigned char>(y - 3, x + 2)
					, img.at<unsigned char>(y - 3, x + 1)
					, img.at<unsigned char>(y - 3, x)
					, img.at<unsigned char>(y - 3, x - 1)
					, img.at<unsigned char>(y - 3, x - 2)
					, img.at<unsigned char>(y - 3, x - 3)
				};

				unsigned char p = img.at<unsigned char>(y, x);

				int out_tmp = 0;

				for (int i = 0; i < 24; i++) {

					out_tmp += (p_src[i] <= p) ? 0 : (1 << i);

				}

				int i = 0;
				int c = count1(out_tmp);

				if (c == 0) {

					feature[23 * 24]++;
					continue;

				}

				if (c == 24) {

					feature[23 * 24 + 1]++;
					continue;

				}

				for (;;) {

					if (((out_tmp & 1) == 1 && (out_tmp & (1 << 23)) >> 23 == 1)
						|| (out_tmp & 1) == 0) {

						out_tmp = out_tmp >> 1 | (out_tmp & 1) << 23;
						i++;

					}

					else if ((out_tmp & 1) == 1 && (out_tmp & (1 << 23)) >> 23 == 0)
						break;

				}

				out_tmp = out_tmp >> c;

				if (out_tmp == 0)
					feature[(c - 1) * 24 + i]++;

				else
					feature[23 * 24 + 2]++;

			}

		}

	}

	return feature;

}