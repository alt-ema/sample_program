//**************************************************************************
//Higher order Local Auto-Correlations
//dimension : 25
//**************************************************************************

#pragma once

#include "feature.h"

using namespace std;
using namespace cv;

//**************************************************************************
//�R���X�^���g���X�g
//**************************************************************************
static const int HLAC_DIMENSION = 25;

//**************************************************************************
//HLAC�N���X
//**************************************************************************
class CHLACfeature : public CFeature
{

public:

	CHLACfeature()
		: CFeature(HLAC_DIMENSION)
	{
	
		cout << "������feature type : HLAC������" << endl;

	}

	vector< float > extract(Mat img);

};
