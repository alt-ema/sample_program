//This source do not use.
//**************************************************************************
//nearest neighbor
//**************************************************************************

/*
float Euclidean_Distance(vector<float> v1, vector<float> v2){

	if (v1.size() != v2.size())
		return -1;

	float r = 0;

	for (unsigned int i = 0; i < v1.size(); i++){

		r += pow(v1[i] - v2[i], 2);

	}

	return sqrt(r);

}


void NN(vector< pair< string, vector<float> > > train,
	vector<int> flag,
	vector< pair< string, vector<float> > > test,
	vector<float>* result,
	ofstream* ofs,
	int cls)
{

	vector<float> arr(cls, 0);
	int r = -1;
	int great = 0;

	for (unsigned int i = 0; i < test.size(); i++){

		for (unsigned int j = 0; j < train.size(); j++){

			arr[j / (test.size() / cls)] += Euclidean_Distance(test[i].second, train[j].second);

		}

		float min;

		for (unsigned int l = 0; l < arr.size(); l++){

			if (l == 0){

				min = arr[l];
				r = l;

			}

			if (min > arr[l]){

				min = arr[l];
				r = l;

			}

		}

		//cout << r << " " << flag[i] << endl;

		if (r == flag[i])
			great++;

		arr.clear();

		for (int l = 0; l < cls; l++)
			arr.push_back(0);

		r = -1;

	}

	result->push_back((float)great / test.size());

}



void K_NN(unsigned int k,
	vector< pair< string, vector<float> > > train,
	vector<int> flag,
	vector< pair< string, vector<float> > > test,
	vector<float>* result,
	ofstream* ofs,
	int cls)
{

	vector< pair<int, float> > rank(train.size());
	vector<int> arr(cls, 0);
	int r = -1;
	int great = 0;

	for (unsigned int i = 0; i < test.size(); i++){

		for (unsigned int j = 0; j < train.size(); j++){

			rank[j].first = flag[j];
			rank[j].second = Euclidean_Distance(train[j].second, test[i].second);

		}

		sort(rank.begin(),
			rank.end(),
			[](const pair<int, double>& x, const pair<int, double>& y)
		{

			return x.second < y.second;

		});

		for (unsigned int l = 0; l < k; l++){

			//cout << rank[l].first << endl;
			arr[rank[l].first]++;

		}

		int max = 0;

		for (unsigned int l = 0; l < arr.size(); l++){

			//cout << (i/test.size())+1 << " " << l << " " << arr[l] << endl;

			if (max < arr[l]){

				max = arr[l];
				r = l;

			}

		}

		//cout << r << endl;

		if (r == flag[i])
			great++;

		arr.clear();

		for (int l = 0; l < cls + 1; l++)
			arr.push_back(0);

		r = -1;

	}

	result->push_back((float)great / test.size());

}
*/
