//**************************************************************************
//Support Vector Machine
//**************************************************************************

#pragma once

#include "classify.h"

using namespace std;
using namespace cv;

//**************************************************************************
//SVM�w�K�N���X
//**************************************************************************
class CSVM_train : public CClassify_train
{

public:

	CSVM_train(CDataSet* dataSet, CFeature* feature, string fileName);

	void run();

protected:

	CvSVM svm;
	CvSVMParams params;

};

//**************************************************************************
//SVM�F���N���X
//**************************************************************************
class CSVM_recog : public CClassify_recog
{

public:

	CSVM_recog(string imageFile, CFeature* feature, string fileName);

	void run();

protected:

	CvSVM svm;
	CvSVMParams params;

};
