//**************************************************************************
//��Ď�@
//dimension : 256
//**************************************************************************

#include "proposed.h"

//**************************************************************************
//��Ď�@ �����ʂ̎Z�o
//Mat		: �Z�o�摜
//return	: ������
//**************************************************************************
vector< float > CProposedfeature::extract(Mat img)
{

	vector<float> feature(PROPOSED_DIMENSION, 0);

	if (!img.empty()) {

		Mat img_ori(img.rows, img.cols, CV_64F);
		Mat img_mag(img.rows, img.cols, CV_64F);
		int r = img.rows - 1;	//�s
		int c = img.cols - 1;	//��

		double x_grad, y_grad;

		for (int y = 0; y < r + 1; y++) {

			for (int x = 0; x < c + 1; x++) {

				if (x == 0)
					x_grad = img.at<unsigned char>(y, 0) - img.at<unsigned char>(y, 1);

				else if (x == c)
					x_grad = img.at<unsigned char>(y, c - 1) - img.at<unsigned char>(y, c);

				else
					x_grad = img.at<unsigned char>(y, x - 1) - img.at<unsigned char>(y, x + 1);

				if (y == 0)
					y_grad = img.at<unsigned char>(0, x) - img.at<unsigned char>(1, x);

				else if (y == r)
					y_grad = img.at<unsigned char>(r - 1, x) - img.at<unsigned char>(r, x);

				else
					y_grad = img.at<unsigned char>(y - 1, x) - img.at<unsigned char>(y + 1, x);

				img_ori.at<double>(y, x) = (atan2(y_grad, x_grad) * 180.0 / CV_PI);
				img_mag.at<double>(y, x) = sqrt(pow(x_grad, 2) + pow(y_grad, 2));

			}

		}

		for (int y = 1; y < r; y++) {

			for (int x = 1; x < c; x++) {

				double p_src[] = {
					img_ori.at<double>(y, x - 1)
					, img_ori.at<double>(y + 1, x)
					, img_ori.at<double>(y, x + 1)
					, img_ori.at<double>(y - 1, x)
				};

				double p = (img_ori.at<double>(y, x - 1) + img_ori.at<double>(y + 1, x - 1) +
					img_ori.at<double>(y + 1, x) + img_ori.at<double>(y + 1, x + 1) +
					img_ori.at<double>(y, x + 1) + img_ori.at<double>(y - 1, x + 1) +
					img_ori.at<double>(y - 1, x) + img_ori.at<double>(y - 1, x + 1) +
					img_ori.at<double>(y, x)) / 9;

				double q_src[] = {
					img_mag.at<double>(y, x - 1)
					, img_mag.at<double>(y + 1, x)
					, img_mag.at<double>(y, x + 1)
					, img_mag.at<double>(y - 1, x)
				};

				double q = (img_mag.at<double>(y, x - 1) + img_mag.at<double>(y + 1, x - 1) +
					img_mag.at<double>(y + 1, x) + img_mag.at<double>(y + 1, x + 1) +
					img_mag.at<double>(y, x + 1) + img_mag.at<double>(y - 1, x + 1) +
					img_mag.at<double>(y - 1, x) + img_mag.at<double>(y - 1, x + 1) +
					img_mag.at<double>(y, x)) / 9;

				int out_tmp = 0;

				for (int i = 0; i < 4; i++) {

					if ((p_src[i] - p >= 0 && p_src[i] - p < 180)
						|| (p_src[i] - p >= -360 && p_src[i] - p < -180))
						out_tmp += 0;

					else
						out_tmp += (1 << i);

				}

				for (int i = 0; i < 4; i++) {

					out_tmp += (q_src[i] <= q) ? 0 : (1 << (4 + i));

				}

				feature[out_tmp]++;

			}

		}

	}

	return feature;

}
