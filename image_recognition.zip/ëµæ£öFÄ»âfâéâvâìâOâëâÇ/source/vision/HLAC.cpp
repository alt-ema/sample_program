//**************************************************************************
//Higher order Local Auto-Correlations
//dimension : 25
//**************************************************************************

#include "HLAC.h"

//**************************************************************************
//HLAC �����ʂ̎Z�o
//Mat		: �Z�o�摜
//return	: ������
//**************************************************************************
vector< float > CHLACfeature::extract(Mat img)
{

	vector<float> feature(HLAC_DIMENSION, 0);

	if (!img.empty()) {

		threshold(img, img, 0, 255, THRESH_BINARY | THRESH_OTSU);
		int r = img.rows - 1;	//�s
		int c = img.cols - 1;	//��

		string maskpattern[25] = {
			"000010000", "000011000", "001010000", "010010000", "100010000",
			"000111000", "001010100", "010010010", "100010001", "001110000",
			"010010100", "100010010", "000110001", "000011100", "001010010",
			"010010001", "100011000", "010110000", "100010100", "000110010",
			"000010101", "000011010", "001010001", "010011000", "101010000"
		};

		float k = 1;
		float sum = 0;

		for (int i = 0; i < 25; i++) {

			for (int y = 1; y < r; y++) {	//�s�N�Z������s

				for (int x = 1; x < c; x++) {	//�s�N�Z�������

					unsigned char p[] = {
						img.at<unsigned char>(y - 1, x - 1),
						img.at<unsigned char>(y - 1, x),
						img.at<unsigned char>(y - 1, x + 1),
						img.at<unsigned char>(y, x - 1),
						img.at<unsigned char>(y, x),
						img.at<unsigned char>(y, x + 1),
						img.at<unsigned char>(y + 1, x - 1),
						img.at<unsigned char>(y + 1, x),
						img.at<unsigned char>(y + 1, x + 1)
					};

					k *= (maskpattern[i].at(0) == '1') ? img.at<unsigned char>(y - 1, x - 1) : 1;
					k *= (maskpattern[i].at(1) == '1') ? img.at<unsigned char>(y - 1, x) : 1;
					k *= (maskpattern[i].at(2) == '1') ? img.at<unsigned char>(y - 1, x + 1) : 1;
					k *= (maskpattern[i].at(3) == '1') ? img.at<unsigned char>(y, x - 1) : 1;
					k *= img.at<unsigned char>(y, x);			//���ڃs�N�Z��
					k *= (maskpattern[i].at(5) == '1') ? img.at<unsigned char>(y, x + 1) : 1;
					k *= (maskpattern[i].at(6) == '1') ? img.at<unsigned char>(y + 1, x - 1) : 1;
					k *= (maskpattern[i].at(7) == '1') ? img.at<unsigned char>(y + 1, x) : 1;
					k *= (maskpattern[i].at(8) == '1') ? img.at<unsigned char>(y + 1, x + 1) : 1;

					feature[i] += k;
					sum += k;
					k = 1;

				}

			}

		}

		for (int i = 0; i < 25; i++)
			feature[i] /= sum;

	}

	return feature;

}