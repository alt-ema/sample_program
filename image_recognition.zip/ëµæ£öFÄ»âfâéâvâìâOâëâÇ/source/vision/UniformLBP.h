//**************************************************************************
//Uniform Local Binary Pattern
//1dim uniform LBP dimension : 59
//2dim uniform LBP dimension : 243
//3dim uniform LBP dimension : 555
//**************************************************************************

#pragma once

#include "feature.h"

using namespace std;
using namespace cv;

//**************************************************************************
//�R���X�^���g���X�g
//**************************************************************************
static const int ULBP1_DIMENSION = 59;
static const int ULBP2_DIMENSION = 243;
static const int ULBP3_DIMENSION = 555;

//**************************************************************************
//uniformLBP1�N���X
//**************************************************************************
class CUniformLBP1 : public CFeature
{

public:

	CUniformLBP1()
		: CFeature(ULBP1_DIMENSION)
	{
	
		cout << "������feature type : uniform LBP1������" << endl;

	}

	vector< float > extract(Mat img);

};

//**************************************************************************
//uniformLBP2�N���X
//**************************************************************************
class CUniformLBP2 : public CFeature
{

public:

	CUniformLBP2()
		: CFeature(ULBP2_DIMENSION)
	{
	
		cout << "������feature type : uniform LBP2������" << endl;

	}

	vector< float > extract(Mat img);

};

//**************************************************************************
//uniformLBP3�N���X
//**************************************************************************
class CUniformLBP3 : public CFeature
{

public:

	CUniformLBP3()
		: CFeature(ULBP3_DIMENSION)
	{
	
		cout << "������feature type : uniform LBP3������" << endl;

	}

	vector< float > extract(Mat img);

};
