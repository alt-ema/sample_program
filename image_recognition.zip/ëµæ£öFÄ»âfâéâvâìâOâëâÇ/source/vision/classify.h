//**************************************************************************
//�@�B�w�K�N���X
//**************************************************************************

#pragma once

#include <vector>
#include "opencv2\opencv.hpp"
#include "opencv_lib.hpp"

using namespace std;
using namespace cv;

class CDataSet;
class CFeature;

//**************************************************************************
//�R���X�^���g���X�g
//**************************************************************************
static const int NEGATIVE = 0;
static const int POSITIVE = 1;

//**************************************************************************
//�@�B�w�K�N���X �w�K
//**************************************************************************
class CClassify_train
{

public:

	CClassify_train(CDataSet* dataSet, CFeature* feature, string fileName);

	void extract(int flag, vector< string > sample);
	void makeLearningData(Mat* flagMat, Mat* dataMat);
	virtual void run() = 0;

protected:

	int dimension;
	CDataSet* dataSet;
	CFeature* feature;
	vector< pair< int, vector< float > > > sample;
	string fileName;

};

//**************************************************************************
//�@�B�w�K�N���X �F��
//**************************************************************************
class CClassify_recog
{

public:

	CClassify_recog(string imageName, CFeature* feature, string fileName);

	virtual void run() = 0;

protected:

	int dimension;
	CDataSet* dataSet;
	CFeature* feature;
	vector< float > sample;
	string fileName;
	string imageName;

};
