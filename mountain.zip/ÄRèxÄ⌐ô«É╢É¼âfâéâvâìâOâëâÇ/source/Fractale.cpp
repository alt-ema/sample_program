//**************************************************************************
//�t���N�^���N���X
//**************************************************************************
//�}�W�b�N�i���o�[����
//��Œ������� 2010/12/3
#include "Fractale.h"
#define EXTERN

//**************************************************************************
//�^�X�N���X�g�̕`��
//**************************************************************************
void DrawTask(CTaskList* list) {

	for (CTaskIter i(list); i.HasNext(); ) {

		CPolygon* polygon = static_cast<CPolygon*>(i.Next());

		if (polygon->Level == Lv)
			polygon->Draw();

	}

}

//**************************************************************************
//����
//**************************************************************************
int Search(VECTOR point) {

	int id;

	for (id = 0; id < PointID; id++) {

		if (point.x == Pt[id].x && point.y == Pt[id].y)
			return id;

	}

	return -1;

}

//**************************************************************************
//�R���X�g���N�^
//**************************************************************************
CFractale::CFractale(int x, int y, int window, char* window_text) {

	SetMainWindowText(window_text);
	SetGraphMode(x, y, 32);
	ChangeWindowMode(TRUE);
	Light = VGet(-5000, 0, 500);
	Lv = 1;
	Flag = TRUE;
	PointID = 3;
	Pt[0] = VGet(800 * cos(0.0f), 800 * sin(0.0f), 0);
	Pt[1] = VGet(800 * cos(2 * D3DX_PI / 3), 800 * sin(2 * D3DX_PI / 3), 0);
	Pt[2] = VGet(800 * cos(4 * D3DX_PI / 3), 800 * sin(4 * D3DX_PI / 3), 0);
	Ave = Time = 0;
	FpsCount = Count0t = 0;
	memset(F, 0, sizeof(FLAME));
	memset(Key, 0, sizeof(Key));

}

//**************************************************************************
//�`��
//**************************************************************************
void CFractale::Draw() {

	DrawTask(PolygonList);

}

//**************************************************************************
//�O���[�o���ϐ��̏�����
//**************************************************************************
void CFractale::Format() {

	Angle = 0;
	CameraPos.x = -2000 * cos(Angle);
	CameraPos.y = -2000 * sin(Angle);
	CameraPos.z = 500.0f;

	PolygonList = new CTaskList(sizeof(CPolygon), 30000);
	Tri = new CPolygon(&Pt[0], &Pt[1], &Pt[2], 1);

}

//**************************************************************************
//�L�[����
//**************************************************************************
void CFractale::GetKey() {

	int mul = 1;

	for (int i = 0; i < 16; i++) {

		if (GetJoypadInputState(DX_INPUT_KEY_PAD1) & mul)
			Key[i]++;
		else
			Key[i] = 0;

		mul *= 2;

	}

}

//**************************************************************************
//�t���N�^���������C������
//**************************************************************************
void CFractale::Run() {

	GetKey();

	if (CheckHitKey(KEY_INPUT_UP) == 1)
		CameraPos.z += 40.0f;

	if (CheckHitKey(KEY_INPUT_DOWN) == 1)
		CameraPos.z -= 40.0f;

	if (CheckHitKey(KEY_INPUT_LEFT) == 1)
		Angle += 0.025f;

	if (CheckHitKey(KEY_INPUT_RIGHT) == 1)
		Angle -= 0.025f;

	if (Key[4] == 1) {

		if (Lv != 1)
			Lv--;

	}

	if (Key[5] == 1) {

		if (Lv != 8)
			Lv++;

	}

	if (Key[6] == 1) {

		Flag = (Flag == TRUE) ? FALSE : TRUE;

	}

	CameraPos.x = -1200 * cos(Angle);
	CameraPos.y = -1200 * sin(Angle);

	SetCameraPositionAndTargetAndUpVec(CameraPos, VGet(0.0f, 0.0f, 0.0f), VGet(0.0f, 0.0f, 1.0f));

	Draw();

}

//**************************************************************************
//��������
//**************************************************************************
void CFractale::Wait(DWORD j) {

	DWORD dw, dw2;

	while (j > (dw2 = ((dw = timeGetTime()) - dwLastFlipped) * 3 + dwErrorValue))
		Sleep(1);

	int i;
	static int t = 0, f[30];
	static double ave = 0;

	f[Time % 30] = (dw2 / 3);

	if (Time % 30 == 29) {

		ave = 0;

		for (i = 0; i < 30; i++)
			ave += f[i];

		ave /= 30;

	}

	if (ave != 0 && j == 50)
		DrawFormatString(0, 585, GetColor(255, 255, 255), "%.2f", 1000 / (double)ave);

	dwLastFlipped = dw;
	dwErrorValue = dw2 % 50;

	return;

}

//**************************************************************************
//���[�v
//**************************************************************************
int CFractale::Loop() {

	if (ProcessMessage() != 0) return -1;
	if (ClearDrawScreen() != 0) return -1;
	return 0;

}
