//**************************************************************************
//�t���N�^���N���X
//**************************************************************************
#include "Fractale.h"

//**************************************************************************
//�R���X�g���N�^
//**************************************************************************
CPolygon::CPolygon(VECTOR *pos1, VECTOR *pos2, VECTOR *pos3, int level)
	: CTask(PolygonList)
{
	int nextlevel = level + 1;
	Level = level;
	Color = 0;
	Pos1 = pos1;
	Pos2 = pos2;
	Pos3 = pos3;
	Norm = VGet(0, 0, 1);
	Func();

	if (Level != LEVEL) {

		new CPolygon(MPos1, MPos2, MPos3, nextlevel);
		new CPolygon(Pos1, MPos3, MPos2, nextlevel);
		new CPolygon(Pos2, MPos1, MPos3, nextlevel);
		new CPolygon(Pos3, MPos2, MPos1, nextlevel);

	}

}

//**************************************************************************
//���z������ �� ��������
//**************************************************************************
void* CPolygon::operator new(size_t n){

	return PolygonList->New(n);

}

//**************************************************************************
//�������� �� ���z������
//**************************************************************************
void CPolygon::operator delete(void* p) {

	PolygonList->Delete(p);

}

//**************************************************************************
//�x�N�g���Z�o
//**************************************************************************
void CPolygon::Func() {

	Middle(*Pos1, *Pos2, *Pos3);
	Normal(*Pos1, *Pos2, *Pos3);
	Inner(Light, Norm);

}

//**************************************************************************
//�|���S���`��
//**************************************************************************
void CPolygon::Draw() {

	DrawTriangle3D(*Pos1, *Pos2, *Pos3, GetColor(0, 128 + Color / 48, 0), Flag);

}

//**************************************************************************
//�t���b�g�V�F�[�f�B���O�p�`��F�̎Z�o
//**************************************************************************
void CPolygon::Inner(VECTOR vec1, VECTOR vec2) {

	Color = VDot(vec1, vec2);

}

//**************************************************************************
//���_�ψ�
//**************************************************************************
void CPolygon::Middle(VECTOR pos1, VECTOR pos2, VECTOR pos3) {

	int id;

	Pt[PointID] = VAdd(pos2, pos3);
	Pt[PointID] = VScale(Pt[PointID], 0.5f);
	id = Search(Pt[PointID]);
	if (id >= 3) {

		MPos1 = &Pt[id];

	}
	else {

		Pt[PointID] = VAdd(Pt[PointID], VGet(0, 0, (GetRand(1200) - 600) / pow((double)2, Level)));
		MPos1 = &Pt[PointID];
		PointID++;

	}

	Pt[PointID] = VAdd(pos3, pos1);
	Pt[PointID] = VScale(Pt[PointID], 0.5f);
	id = Search(Pt[PointID]);
	if (id >= 3) {

		MPos2 = &Pt[id];

	}
	else {

		Pt[PointID] = VAdd(Pt[PointID], VGet(0, 0, (GetRand(1200) - 600) / pow((double)2, Level)));
		MPos2 = &Pt[PointID];
		PointID++;

	}

	Pt[PointID] = VAdd(pos1, pos2);
	Pt[PointID] = VScale(Pt[PointID], 0.5f);
	id = Search(Pt[PointID]);
	if (id >= 3) {

		MPos3 = &Pt[id];

	}
	else {

		Pt[PointID] = VAdd(Pt[PointID], VGet(0, 0, (GetRand(1200) - 600) / pow((double)2, Level)));
		MPos3 = &Pt[PointID];
		PointID++;

	}

}

//**************************************************************************
//�@���x�N�g���̎Z�o
//**************************************************************************
void CPolygon::Normal(VECTOR pos1, VECTOR pos2, VECTOR pos3) {

	VECTOR temp1, temp2;

	temp1 = VSub(pos2, pos1);
	temp2 = VSub(pos3, pos1);

	Norm = VCross(temp1, temp2);
	Norm = VScale(Norm, 1 / VSize(Norm));

}
