/**************************************************************************/
/*���C���N���X                                                            */
/**************************************************************************/

#include "line.h"

//**************************************************************************
//�R���X�g���N�^
//**************************************************************************
CLine::CLine( VECTOR2D point1, VECTOR2D point2, char pattern )
{
	//�Z�b�^�[�ǂݏo��
	set( point1, point2, true );

	if( pattern == LINE_A ){			//�p�^�[��A

		firstEdge	= false;
		lastEdge	= false;

	}else if( pattern == LINE_B ){		//�p�^�[��B

		firstEdge	= false;
		lastEdge	= true;

	}else if( pattern == LINE_C ){		//�p�^�[��C

		firstEdge	= true;
		lastEdge	= false;

	}else if( pattern == LINE_D ){		//�p�^�[��D

		firstEdge	= true;
		lastEdge	= true;

	}
}

//**************************************************************************
//�e�ϐ��̐ݒ�
//**************************************************************************
void CLine::set( VECTOR2D point1, VECTOR2D point2, bool flag ){

	point[0].set( point1.x, point1.y );
	point[1].set( point2.x, point2.y );

	if( flag == true ){

		lineVector.set( point[1].x - point[0].x, point[1].y - point[0].y );
		normalVector.set( lineVector.y, -lineVector.x );
		normalUnitVector.set( normalVector.x / sqrt( pow( normalVector.x, 2 ) + pow( normalVector.y, 2 ) ),
			normalVector.y / sqrt( pow( normalVector.x, 2 ) + pow( normalVector.y, 2 ) ) );
		length = sqrt( lineVector.x * lineVector.x + lineVector.y * lineVector.y );
		cosValue = sinValue = tanValue = 0;

		if( length != 0 ){
		
			cosValue = lineVector.x / length;
			sinValue = lineVector.y / length;
		
		}

		if( lineVector.x != 0 )
			tanValue = lineVector.y / lineVector.x;

		//else//if( lineVector.x ==0 )		//���ʂȏ����̂��߃R�����g�A�E�g
		//	tanValue = 0;

		sita = acos( cosValue ) * 180.0F / D3DX_PI;

	}

}

//**************************************************************************
//�X�V(���W�̂�)
//**************************************************************************
void CLine::update( VECTOR2D vec ){

	point[0].add( vec.x, vec.y );
	point[1].add( vec.x, vec.y );

}

//**************************************************************************
//VECTOR2D : �J�������W�n�̌��_
//**************************************************************************
#ifdef _DEBUG
void CLine::debug( VECTOR2D revise ){

	DrawCircle( point[0].x-revise.x, point[0].y-revise.y, 4, GetColor( 255, 0, 0 ), 1 );
	DrawCircle( point[1].x-revise.x, point[1].y-revise.y, 4, GetColor( 0, 255, 0 ), 1 );
	DrawLine( point[0].x-revise.x, point[0].y-revise.y, point[1].x-revise.x, point[1].y-revise.y, GetColor(255, 0, 0) );

}
#endif
