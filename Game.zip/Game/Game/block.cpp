/**************************************************************************/
/*�}�`��`                                                                */
/**************************************************************************/

#include "object.h"
#include "block.h"
#include "line.h"
#include "rejection.h"
#include "stage_manager.h"

//**************************************************************************
//�R���X�g���N�^(�C���^�[�t�F�[�X�g�p)
//VECTOR2D : �E��̍��W
//BLOCK_IF : ���̑��p�����[�^
//**************************************************************************
CBlock::CBlock( VECTOR2D point, BLOCK_IF blockPattern )
{
	//block
	this->lineNum		= blockPattern.lineNum;
	this->width			= blockPattern.width;
	this->height		= blockPattern.height;

	//object
	CObject::center		= getVector( point.x + width / 2, point.y + height / 2 );
	CObject::color		= 255;
	CObject::timer		= 0;
	CObject::image		= blockPattern.image;
	CObject::collision	= NULL;
	CObject::row		= center.y / CELL_Y_LENGTH;
	CObject::col		= center.x / CELL_X_LENGTH;
	CObject::moveVector	= getVector( 0, 0 );

	if( lineNum == 3 )
		CObject::rejection	= new CRejection(
		addVector( point, blockPattern.point[0] ),
		addVector( point, blockPattern.point[1] ),
		addVector( point, blockPattern.point[2] ),
		blockPattern.pattern );

	else// if( lineNum == 4 )
		CObject::rejection	= new CRejection(
		addVector( point, blockPattern.point[0] ),
		addVector( point, blockPattern.point[1] ),
		addVector( point, blockPattern.point[2] ),
		addVector( point, blockPattern.point[3] ),
		blockPattern.pattern );

}

//**************************************************************************
//list< CObject* > : �r�����镨��
//**************************************************************************
void CBlock::reject( list< CObject* > rejectList ){}

//**************************************************************************
//VECTOR2D : �J�������W�n�̌��_
//**************************************************************************
void CBlock::draw( VECTOR2D revise ){

	SetDrawBright( color, color, color );
	//DrawRotaGraphF( center.x - revise.x, center.y - revise.y, 1, 0, image, TRUE, 0 );

#ifdef _DEBUG
	debug( revise );
#endif

}

//**************************************************************************
//�_�~�[�u���b�N(�`��݂̂̃u���b�N)
//**************************************************************************
CDummyBlock::CDummyBlock( VECTOR2D center, DUMMYBLOCK_IF dummyBlockPattern )
{
	//object
	CObject::center		= center;
	CObject::color		= 255;
	CObject::timer		= 0;
	CObject::image		= dummyBlockPattern.image;
	CObject::collision	= NULL;
	CObject::rejection	= NULL;
	CObject::row		= center.y / CELL_Y_LENGTH;
	CObject::col		= center.x / CELL_X_LENGTH;
	CObject::moveVector	= getVector( 0, 0 );

	//dummyBlock
	this->width			= dummyBlockPattern.width;
	this->height		= dummyBlockPattern.height;
}

//**************************************************************************
//VECTOR2D : �J�������W�n�̌��_
//**************************************************************************
void CDummyBlock::draw( VECTOR2D revise ){

	SetDrawBright( color, color, color );
	//DrawRotaGraphF( center.x - revise.x, center.y - revise.y, 1, 0, image, TRUE, 0 );

#ifdef _DEBUG
	debug( revise );
#endif

}

//**************************************************************************
//VECTOR2D : �J�������W�n�̌��_
//**************************************************************************
#ifdef _DEBUG
void CDummyBlock::debug( VECTOR2D revise ){

	DrawCircle( center.x - revise.x, center.y - revise.y, 4, GetColor( 255, 255, 255 ), 1 );
	//DrawBox( center.x-revise.x-CELL_X_LENGTH/2, center.y-revise.y-CELL_Y_LENGTH/2,
	//	center.x-revise.x+CELL_X_LENGTH/2, center.y-revise.y+CELL_Y_LENGTH/2,
	//	GetColor( 0, 0, 255 ), 1 );

}
#endif
