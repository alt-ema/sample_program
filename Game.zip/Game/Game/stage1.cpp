/**************************************************************************/
/*�X�e�[�W1�N���X                                                         */
/**************************************************************************/

#include "stage1.h"
#include "player.h"
#include "block.h"

//**************************************************************************
//�R���X�g���N�^
//**************************************************************************
CStage1::CStage1()
{
	life = 2;
	difficult = 0;
	timer = 0;
	mode = 0;
	score = 0;
	cameraVector.set( 0, 0 );

	loadImage();
	loadStage();
}

//**************************************************************************
//�f�X�g���N�^(�����ƒ�`���邱��)
//**************************************************************************
CStage1::~CStage1()
{
	deleteStage();
	deleteImage();
}

//**************************************************************************
//�X�e�[�W����(1�t���[��)
//**************************************************************************
void CStage1::run(){

	//step1 �ړ�����
	//moveManager( blockList );
	//moveManager( dummyBlockList );
	//moveManager( enemyList );
	//moveManager( bossList );
	//moveManager( itemList );
	//moveManager( effectList );
	player->move();

	//step2 �\�����r��
	player->reject( blockList );

	//step3 ���W�X�V
	//updateManager( blockList );
	//updateManager( dummyBlockList );
	//updateManager( enemyList );
	//updateManager( bossList );
	//updateManager( itemList );
	//updateManager( effectList );
	player->update();

	//step4 �I�u�W�F�N�g����
	//runManager( blockList );
	//runManager( dummyBlockList );
	//runManager( enemyList );
	//runManager( bossList );
	//runManager( itemList );
	//runManager( effectList );
	player->run();

	//for cameraVector
	camera();			//stage run

	// step5 �X�e�[�W�`��
	/*
	�X�e�[�W�w�i�̕`�ʂ͂����ɂ���
	*/
	drawManager( blockList, cameraVector );
	drawManager( dummyBlockList, cameraVector );
	//drawManager( enemyList, cameraVector );
	//drawManager( bossList, cameraVector );
	//drawManager( itemList, cameraVector );
	//drawManager( effectList, cameraVector );	
	player->draw( cameraVector );

	//other
	calcTimer();

}

//**************************************************************************
//�摜�ǂݍ���
//**************************************************************************
void CStage1::loadImage(){

	//for player
	stand.push_back( LoadGraph( "data/character/player1/stand/stand000.png", TRUE ) );
	stand.push_back( LoadGraph( "data/character/player1/stand/stand001.png", TRUE ) );
	stand.push_back( LoadGraph( "data/character/player1/stand/stand002.png", TRUE ) );
	stand.push_back( LoadGraph( "data/character/player1/stand/stand003.png", TRUE ) );
	stand.push_back( LoadGraph( "data/character/player1/stand/stand004.png", TRUE ) );
	stand.push_back( LoadGraph( "data/character/player1/stand/stand005.png", TRUE ) );
	stand.push_back( LoadGraph( "data/character/player1/stand/stand006.png", TRUE ) );
	stand.push_back( LoadGraph( "data/character/player1/stand/stand007.png", TRUE ) );
	stand.push_back( LoadGraph( "data/character/player1/stand/stand008.png", TRUE ) );
	stand.push_back( LoadGraph( "data/character/player1/stand/stand009.png", TRUE ) );
	// ***************************************************************************
	walk.push_back( LoadGraph( "data/character/player1/walk/stand000.png", TRUE ) );
	walk.push_back( LoadGraph( "data/character/player1/walk/stand001.png", TRUE ) );
	walk.push_back( LoadGraph( "data/character/player1/walk/stand002.png", TRUE ) );
	walk.push_back( LoadGraph( "data/character/player1/walk/stand003.png", TRUE ) );
	walk.push_back( LoadGraph( "data/character/player1/walk/stand004.png", TRUE ) );
	walk.push_back( LoadGraph( "data/character/player1/walk/stand005.png", TRUE ) );
	walk.push_back( LoadGraph( "data/character/player1/walk/stand006.png", TRUE ) );
	walk.push_back( LoadGraph( "data/character/player1/walk/stand007.png", TRUE ) );

	playerImage.push_back( stand );
	playerImage.push_back( walk );

	//for block, dummyblock
	blockImage.push_back( LoadGraph( "data/stage/debug/01_0000.png", TRUE ) );
	blockImage.push_back( LoadGraph( "data/stage/debug/01_0001.png", TRUE ) );

}

//**************************************************************************
//�X�e�[�W�t�@�C���ǂݍ���, �e�C���X�^���X��
//int    : �s
//int    : ��
//string : �C���X�^���X�p�^�[��    1������ : �C���X�^���X�̎��, 2�����ڈȍ~ : �p�^�[��
//**************************************************************************
void CStage1::makeInstance( int row, int col, string pattern ){

	//�G���[�`�F�b�N
	if( pattern.length() <= 1 )
		return;

	switch( pattern[0] ){

		case 'B':{		//�u���b�N

			if( blockMap.find( pattern ) != blockMap.end() )				//�L�[�����݂���
				blockList.push_back( new CBlock( getVector( col * CELL_X_LENGTH, row * CELL_Y_LENGTH ),
					blockMap[pattern] ) );
			break;

				 }
		case 'D':		//�_�~�[�u���b�N

			if( dummyBlockMap.find( pattern ) != dummyBlockMap.end() )		//�L�[�����݂���
				dummyBlockList.push_back( new CDummyBlock( getVector( col * CELL_X_LENGTH, row * CELL_Y_LENGTH ),
					dummyBlockMap[pattern] ) );
			break;

	}

}

//**************************************************************************
//�X�e�[�W�t�@�C���ǂݍ���, �e�C���X�^���X��
//**************************************************************************
void CStage1::loadStage(){

	player = new CPlayer( &playerImage, 5, 5, 400, 300 );

	//���[�h�C���X�^���X�p�^�[��
	loadBlock();
	loadDummyBlock();

	int row = 0, col = 0;
	string str;
	ifstream ifs( STAGE_FILE );

	if( !ifs ){

		MessageBox( NULL, TEXT( "stage file�����[�h�ł��܂���B" )
		, TEXT( WINDOW_NAME )
		, MB_OK | MB_ICONSTOP );
		//�I�������������ɏ����B

	}

	while( getline( ifs, str ) ){

		col = 0;
		string pattern;
		istringstream stream( str );
		
		while( getline( stream, pattern, ',' ) ){

			if( pattern == "" ){

				col++;
				continue;

			}else if( pattern.find( ";" ) != string::npos ){

				string cellPattern;
				istringstream cellStream( pattern );

				while( getline( cellStream, cellPattern, ';' ) ){

					makeInstance( row, col, cellPattern );

				}

			}else{

				makeInstance( row, col, pattern );

			}

			col++;

		}

		row++;

	}

	ifs.close();

}

//**************************************************************************
//�u���b�N�ǂݍ���
//**************************************************************************
void CStage1::loadBlock(){

	string str;
	string key;
	ifstream ifs( BLOCK_FILE );

	if( !ifs ){

		MessageBox( NULL, TEXT( "block file�����[�h�ł��܂���B" )
		, TEXT( WINDOW_NAME )
		, MB_OK | MB_ICONSTOP );
		//�I�������������ɏ����B

	}

	while( getline( ifs, str ) ){

		string pattern;
		string x, y;
		istringstream stream( str );
		BLOCK_IF tmp;
		
		if( str.substr( 0, 2 ) == "//" || str.find( "[block]" ) != string::npos )
			continue;

		//key for blockmap
		getline( stream, pattern, ',' );
		key = pattern;

		//image
		getline( stream, pattern, ',' );
		tmp.image = blockImage[atoi( pattern.c_str() )];

		//width
		getline( stream, pattern, ',' );
		tmp.width = atoi( pattern.c_str() );

		//height
		getline( stream, pattern, ',' );
		tmp.height = atoi( pattern.c_str() );

		//rejectionPattern
		getline( stream, pattern, ',' );
		tmp.pattern = pattern;

		//lineNum
		getline( stream, pattern, ',' );
		tmp.lineNum = atoi( pattern.c_str() );

		//point
		for( int i = 0; i < tmp.lineNum; i++ ){

			getline( stream, pattern, ',' );
			istringstream pointStream( pattern );
			getline( pointStream, x, ';' );
			getline( pointStream, y, ';' );
			tmp.point.push_back( getVector( atoi( x.c_str() ), atoi( y.c_str() ) ) );

		}

		//if( getline( stream, pattern, ',' ) != EOF )
		//	break;

		blockMap.insert( make_pair( key, tmp ) );

	}

	ifs.close();

}

//**************************************************************************
//�_�~�[�u���b�N�ǂݍ���
//**************************************************************************
void CStage1::loadDummyBlock(){

	string str;
	string key;
	ifstream ifs( DUMMYBLOCK_FILE );

	if( !ifs ){

		MessageBox( NULL, TEXT( "dummyBlock file�����[�h�ł��܂���B" )
		, TEXT( WINDOW_NAME )
		, MB_OK | MB_ICONSTOP );
		//�I�������������ɏ����B

	}

	while( getline( ifs, str ) ){

		string pattern;
		istringstream stream( str );
		DUMMYBLOCK_IF tmp;
		
		if( str.substr( 0, 2 ) == "//" || str.find( "[dummyBlock]" ) != string::npos )
			continue;

		//key for dummyblockmap
		getline( stream, pattern, ',' );
		key = pattern;

		//image
		getline( stream, pattern, ',' );
		tmp.image = blockImage[atoi( pattern.c_str() )];

		//width
		getline( stream, pattern, ',' );
		tmp.width = atoi( pattern.c_str() );

		//height
		getline( stream, pattern, ',' );
		tmp.height = atoi( pattern.c_str() );

		//if( getline( stream, pattern, ',' ) != EOF )
		//	break;

		dummyBlockMap.insert( make_pair( key, tmp ) );

	}

	ifs.close();

}

//**************************************************************************
//�摜���
//**************************************************************************
void CStage1::deleteImage(){

	for( unsigned int i = 0; i < playerImage.size(); i++ ){

		for( unsigned int j = 0; j < playerImage[i].size(); j++ )
			DeleteGraph( playerImage[i][j], 0 );

	}

}

//**************************************************************************
//�C���X�^���X���
//**************************************************************************
void CStage1::deleteStage(){

	//delete����
	//���X�g����O���Ă��̌�delete

}
