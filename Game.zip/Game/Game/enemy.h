/**************************************************************************/
/*�G�N���X�̒�`(�X�[�p�[)                                                */
/**************************************************************************/

#pragma once

#include "main.h"
#include "move.h"

class CEnemy : public CMover{

public:

	CEnemy();

	void move();
	void update();
	void run();
	void draw( VECTOR2D revise );
	void animation();
	void calcStatus();

protected:

	// image =====
	vector< vector< int > > image;
	// ===========

	char EnemyState;

#ifdef _DEBUG
	void debug( VECTOR2D revise );
#endif

};
