/**************************************************************************/
/*���̃N���X(�C���^�[�t�F�[�X)                                            */
/**************************************************************************/

#include "object.h"
#include "collision.h"
#include "rejection.h"
#include "player.h"

//**************************************************************************
//�f�t�H���g�R���X�g���N�^
//**************************************************************************
CObject::CObject()
{
	color = timer = row = col = image = 0;
	center = moveVector = getVector( 0, 0 );
	collision = NULL;
	rejection = NULL;
}

//**************************************************************************
//�X�V����
//**************************************************************************
void CObject::update(){

#ifdef _DEBUG
	DrawFormatString( 600, 585, GetColor( 255, 255, 255 ), "%f : %f", moveVector.x, moveVector.y );
#endif

	center.add( moveVector.x, moveVector.y );
	if( collision != NULL ){ collision->update( moveVector ); }
	if( rejection != NULL ){ rejection->update( moveVector ); }

	//where cell
	row = center.y / CELL_Y_LENGTH;
	col = center.x / CELL_X_LENGTH;
}

//**************************************************************************
//�f�o�b�N�p
//VECTOR2D : �J�������W�n�̌��_
//**************************************************************************
#ifdef _DEBUG
void CObject::debug( VECTOR2D revise ){

	DrawCircle( center.x - revise.x, center.y - revise.y, 4, GetColor( 255, 255, 255 ), 1 );
	if( collision != NULL ){ collision->debug( revise ); }
	if( rejection != NULL ){ rejection->debug( revise ); }

}
#endif
