/**************************************************************************/
/*�X�e�[�W1�N���X                                                         */
/**************************************************************************/

#pragma once

#include "main.h"
#include "stage.h"

class CStage;
class CBoss;

//**************************************************************************
//�R���X�^���g���X�g
//**************************************************************************
//�ݒ�t�@�C��(csv or xml)
static const char* STAGE_FILE		= "stage1.csv";
static const char* DEFINITION_FILE	= "stage1_definition.csv";
static const char* LINE_FILE		= "stage1_line.csv";
static const char* REJECTION_FILE	= "stage1_rejection.csv";
static const char* BLOCK_FILE		= "stage1_block.csv";
static const char* DUMMYBLOCK_FILE	= "stage1_dummyBlock.csv";
//static const char* ENEMY_FILE		= "stage1_enemy.csv";
//static const char* PLAYER_FILE	= "stage1_player.csv";
//static const char* BOSS_FILE		= "stage1_boss.csv";

//**************************************************************************
//�X�e�[�W1
//**************************************************************************
class CStage1 : public CStage{

public:

	// image ========
	//player
	vector< vector< int > > playerImage;
	vector< int > stand;
	vector< int > walk;
	//block, dummyblock
	vector< int > blockImage;

	//enemy
	//boss
	//item
	//effect
	// ==============

	//�{�X�̎����͐�
	//CBoss* boss;
	//CBoss* midBoss;

	CStage1();
	~CStage1();

	void run();
	//void camera();
	void loadImage();

	void makeInstance( int row, int col, string pattern );
	void loadStage();
	void loadBlock();
	void loadDummyBlock();

	void deleteImage();
	void deleteStage();

};
