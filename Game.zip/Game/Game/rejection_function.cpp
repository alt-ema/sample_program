/**************************************************************************/
/*�����蔻�苤�ʊ֐�                                                      */
/**************************************************************************/

#include "collision.h"
#include "line.h"
#include "rejection.h"

//**************************************************************************
//����
//vector1 : �x�N�g��1
//vector2 : �x�N�g��2
//return  : �x�N�g��1�ƃx�N�g��2�̓��ϒl
//**************************************************************************
float dotProduct( VECTOR2D vector1, VECTOR2D vector2 ){

	return vector1.x * vector2.x + vector1.y * vector2.y;

}

//**************************************************************************
//�O��
//vector1 : �x�N�g��1
//vector2 : �x�N�g��2
//return  : �x�N�g��1�ƃx�N�g��2�̊O�ϒl
//**************************************************************************
float crossProduct( VECTOR2D vector1, VECTOR2D vector2 ){

	return vector1.x * vector2.y - vector1.y * vector2.x;

}

//**************************************************************************
//�x�N�g���̂ǂ��瑤��
//VECTOR2D : ���ؓ_
//CLine*   : �x�N�g��
//bool     : true  �E��(����)
 //          false ����(�O��)
//**************************************************************************
bool isLineSide( VECTOR2D point, CLine* line ){

	VECTOR2D tmp;
	tmp.set( point.x - line->point[0].x, point.y - line->point[1].y );

	if( dotProduct( tmp, line->lineVector ) >= 0 )
		return true;

	else if( dotProduct( tmp, line->lineVector ) < 0 )
		return false;

	return false;

}

//**************************************************************************
//��������
//CLine* : �x�N�g��1(�ړ����̂̋O��)
//CLine* : �x�N�g��2(�n�`)
//bool   : �^�U
//**************************************************************************
bool isIntersection( CLine* l1, CLine* l2 ){

	if( l1->sinValue == l2->sinValue || l1->cosValue == l2->cosValue )
		return false;

	VECTOR2D ac, ad;
	VECTOR2D ca, cb;

	ac.set( l2->point[0].x - l1->point[0].x, l2->point[0].y - l1->point[0].y );
	ad.set( l2->point[1].x - l1->point[0].x, l2->point[1].y - l1->point[0].y );
	ca.set( l1->point[0].x - l2->point[0].x, l1->point[0].y - l2->point[0].y );
	cb.set( l1->point[1].x - l2->point[0].x, l1->point[1].y - l2->point[0].y );

	//�n�_����̃`�F�b�N
	if( crossProduct( l1->lineVector, ac ) == 0 && l2->firstEdge == false )
		return false;

	//�I�_����̃`�F�b�N
	if( crossProduct( l1->lineVector, ad ) == 0 && l2->lastEdge == false )
		return false;

	if( crossProduct( l1->lineVector, ac ) * crossProduct( l1->lineVector, ad ) <= 0 &&			//=�L�Œ[�_�𔻒�
		crossProduct( l2->lineVector, ca ) * crossProduct( l2->lineVector, cb ) <= 0 )
		return true;

	return false;

}

//**************************************************************************
//��(��)��������̌�������
//CLine* : �x�N�g��1(�ړ����̂̋O��)
//CLine* : �x�N�g��2(�n�`)
//bool   : �^�U
//**************************************************************************
bool isPositiveIntersection( CLine* l1, CLine* l2 ){

	if( l1->sinValue == l2->sinValue || l1->cosValue == l2->cosValue )
		return false;

	VECTOR2D ac, ad;
	VECTOR2D ca, cb;

	ac.set( l2->point[0].x - l1->point[0].x, l2->point[0].y - l1->point[0].y );
	ad.set( l2->point[1].x - l1->point[0].x, l2->point[1].y - l1->point[0].y );
	ca.set( l1->point[0].x - l2->point[0].x, l1->point[0].y - l2->point[0].y );
	cb.set( l1->point[1].x - l2->point[0].x, l1->point[1].y - l2->point[0].y );

	//�n�_����̃`�F�b�N
	if( crossProduct( l1->lineVector, ac ) == 0 && l2->firstEdge == false )
		return false;

	//�I�_����̃`�F�b�N
	if( crossProduct( l1->lineVector, ad ) == 0 && l2->lastEdge == false )
		return false;

	if( crossProduct( l1->lineVector, ac ) * crossProduct( l1->lineVector, ad ) <= 0 &&			//=�L�Œ[�_�𔻒�
		crossProduct( l2->lineVector, ca ) * crossProduct( l2->lineVector, cb ) <= 0 &&
		crossProduct( l2->lineVector, ca ) <= 0 && crossProduct( l2->lineVector, cb ) >= 0 )
		return true;

	return false;

}

//**************************************************************************
//��`�̓�������
//VECTOR2D : ����̍��W
//VECTOR2D : �E���̍��W
//VECTOR2D : ������W
//bool	 : �^�U
//**************************************************************************
bool isHitRect( VECTOR2D p1, VECTOR2D p2, VECTOR2D q ){

	if( p1.x <= q.x && p2.x >= q.x &&
		p1.y >= q.y && p2.y <= q.y )
		return true;

	else
		return false;

}

//**************************************************************************
//��_���W�̌v�Z
//CLine* : �x�N�g��1
//CLine* : �x�N�g��2
//return : ��_���W
//**************************************************************************
VECTOR2D calcIntersectionPoint( CLine* l1, CLine* l2 ){

	//if( isIntersection( l1, l2 ) == false ){
		//�G���[�`�F�b�N
	//}

	if( l1->sinValue == l2->sinValue || l1->cosValue == l2->cosValue )
		return getVector( 0, 0 );

	VECTOR2D intersection;
	VECTOR2D ca, cb;
	float ratio;
	
	ca.set( l1->point[0].x - l2->point[0].x, l1->point[0].y - l2->point[0].y );
	cb.set( l1->point[1].x - l2->point[0].x, l1->point[1].y - l2->point[0].y );

	ratio = fabs( crossProduct( ca, l2->lineVector ) ) / (fabs( crossProduct( ca, l2->lineVector ) ) + fabs( crossProduct( cb, l2->lineVector ) ));
	intersection.set( l1->point[0].x + l1->lineVector.x * ratio, l1->point[0].y + l1->lineVector.y * ratio );

	return intersection;

}

//**************************************************************************
//��������܂ł̃x�N�g���Z�o
//CLine* : �x�N�g��1(�ړ����̂̋O��)
//CLine* : �x�N�g��2(�n�`)
//return : �x�N�g��1�̌����O����
//**************************************************************************
VECTOR2D calcIntersectionVector1( CLine* l1, CLine* l2 ){

	//if( isIntersection( l1, l2 ) == false ){
		//�G���[�`�F�b�N
	//}

	if( l1->sinValue == l2->sinValue || l1->cosValue == l2->cosValue )
		return getVector( 0, 0 );

	VECTOR2D ret;
	VECTOR2D ca, cb;
	float ratio;
	
	ca.set( l1->point[0].x - l2->point[0].x, l1->point[0].y - l2->point[0].y );
	cb.set( l1->point[1].x - l2->point[0].x, l1->point[1].y - l2->point[0].y );

	ratio = fabs( crossProduct( ca, l2->lineVector ) ) / ( fabs( crossProduct( ca, l2->lineVector ) ) + fabs( crossProduct( cb, l2->lineVector ) ) );
	ret.set( l1->lineVector.x * ratio, l1->lineVector.y * ratio );

	return ret;

}

//**************************************************************************
//������̃x�N�g���Z�o
//CLine* : �x�N�g��1(�ړ����̂̋O��)
//CLine* : �x�N�g��2(�n�`)
//return : �x�N�g��1�̌����㕔��
//**************************************************************************
VECTOR2D calcIntersectionVector2( CLine* l1, CLine* l2 ){

	//if( isIntersection( l1, l2 ) == false ){
		//�G���[�`�F�b�N
	//}

	if( l1->sinValue == l2->sinValue || l1->cosValue == l2->cosValue )
		return getVector( 0, 0 );

	VECTOR2D ret;
	VECTOR2D ca, cb;
	float ratio;
	
	ca.set( l1->point[0].x - l2->point[0].x, l1->point[0].y - l2->point[0].y );
	cb.set( l1->point[1].x - l2->point[0].x, l1->point[1].y - l2->point[0].y );

	ratio = fabs( crossProduct( cb, l2->lineVector ) ) / ( fabs( crossProduct( ca, l2->lineVector ) ) + fabs( crossProduct( cb, l2->lineVector ) ) );
	ret.set( l1->lineVector.x * ratio, l1->lineVector.y * ratio );

	return ret;

}

//**************************************************************************
//�r�����ꂽmoveVector�̎Z�o
//CLine* : �x�N�g��1(�ړ����̂̋O��)
//CLine* : �x�N�g��2(�n�`)
//return : �ړ��x�N�g��
//**************************************************************************
VECTOR2D calcNewVector( CLine* l1, CLine* l2 ){

	VECTOR2D ret;
	float angle = calcCrossAngle( l1, l2 );

	if( ( angle >= 0 && angle <= 45 ) ||
		( angle >= 135 && angle <= 180 ) ){

			if( ( l2->sita >= 0 && l2->sita <= 45 ) ||			//for x
				( l2->sita >= 135 && l2->sita <= 180 ) ){

					ret.x = l1->lineVector.x;
					ret.y = l2->point[0].y + (l1->point[1].x - l2->point[0].x) * l2->tanValue - l1->point[0].y;

			}else{//if( l2->sita > 45 && l2->sita < 135 )		//for y		//�� : ���얢�m�F

				if( l2->tanValue != 0 )
					ret.x = l2->point[0].x + (l1->point[1].y - l2->point[0].y) * (-1 / l2->tanValue) - l1->point[0].x;

				else//if( l2->tanValue == 0 )
					ret.x = l2->point[0].x - l1->point[0].x;

				ret.y = l1->lineVector.y;

			}

	}else//if( angle > 45 && angle < 135 )
		ret = calcIntersectionVector1( l1, l2 );

	return ret;

}

//**************************************************************************
//�����p�x�̎Z�o
//CLine* : �x�N�g��1(�ړ����̂̋O��)
//CLine* : �x�N�g��2(�n�`)
//return : �����p�x( 0 ~ 180�x )
//**************************************************************************
float calcCrossAngle( CLine* l1, CLine* l2 ){

	return acos( dotProduct( l1->lineVector, l2->lineVector ) / ( l1->length * l2->length ) ) * 180.0F / D3DX_PI;

}

//**************************************************************************
//�x�N�g���̒����Z�o
//VECTOR2D : vec
//return   : �x�N�g���̒���
//**************************************************************************
float calcVectorLength( VECTOR2D vec ){

	return sqrt( pow( vec.x, 2.0F ) + pow( vec.y, 2.0F ) );

}

//**************************************************************************
//�_�Ɛ��̋������Z�o
//VECTOR2D : �_
//CLine*   : ��
//return   : 2�̋���
//**************************************************************************
float calcPointLineDist( VECTOR2D point, CLine* line ){

	return dotProduct( getVector( point.x - line->point[0].x, point.y - line->point[0].y ), line->normalUnitVector );

}

//**************************************************************************
//�I�u�W�F�N�g��������
//VECTOR2D    : ����_
//CRejection* : �̈�
//**************************************************************************
bool isInterRejection( VECTOR2D point, CRejection* rejection ){

	VECTOR2D vec;

	for( unsigned int i = 0; i < rejection->line.size(); i++ ){

		vec.set( point.x - rejection->line[i]->point[0].x, point.y - rejection->line[i]->point[0].y );
		if( crossProduct( rejection->line[i]->lineVector, vec ) > 0 )
			return false;

	}

	return true;

}
