/**************************************************************************/
/*�Փ˃N���X                                                              */
/**************************************************************************/

#include "collision.h"
#include "line.h"

//**************************************************************************
//�R���X�g���N�^
//**************************************************************************
CCollision::CCollision(VECTOR2D* moveVector, vector< VECTOR2D > point)
{
	//�ړ��x�N�g���̃A�h���X���L
	this->moveVector = moveVector;

	//�����蔻��̐ݒ�
	for (unsigned int i = 0; i < point.size(); i++)
		this->point.push_back(point[i]);

	//������
	for (unsigned int i = 0; i < point.size(); i++)
		moveLine.push_back(new CLine(point[i], point[i], LINE_D));	//�_�~�[����
}

//**************************************************************************
//�R���X�g���N�^
//**************************************************************************
CCollision::CCollision( VECTOR2D* moveVector, float x, float y, float xHalfWidth, float yHalfWidth  )
{
	//�ړ��x�N�g���̃A�h���X���L
	this->moveVector = moveVector;

	//�����蔻��̐ݒ�
	point.push_back( getVector( x - xHalfWidth, y - yHalfWidth ) );		//COLLISION_LEFT_UP
	point.push_back( getVector( x, y - yHalfWidth ) );					//COLLISION_CENTER_UP
	point.push_back( getVector( x + xHalfWidth, y - yHalfWidth ) );		//COLLISION_RIGHT_UP
	point.push_back( getVector( x + xHalfWidth, y ) );					//COLLISION_LEFT_MIDDLE
	point.push_back( getVector( x, y) );								//COLLISION_CENTER_MIDDLE
	point.push_back( getVector( x + xHalfWidth, y + yHalfWidth ) );		//COLLISION_RIGHT_MIDDLE
	point.push_back( getVector( x, y + yHalfWidth ) );					//COLLISION_LEFT_DOWN
	point.push_back( getVector( x - xHalfWidth, y + yHalfWidth ) );		//COLLISION_CENTER_DOWN
	point.push_back( getVector( x - xHalfWidth, y ) );					//COLLISION_RIGHT_DOWN
	
	//������
	for( unsigned int i = 0; i < point.size(); i++ )
		moveLine.push_back( new CLine( point[i], point[i], LINE_D ) );	//�_�~�[����
}

//**************************************************************************
//���W�̍X�V
//**************************************************************************
void CCollision::update( VECTOR2D vec ){

	for( unsigned int i = 0; i < point.size(); i++ )
		point[i].add( vec.x, vec.y );

}

//**************************************************************************
//�ړ����C���̌v�Z
//**************************************************************************
void CCollision::calcMoveVector(){

	for( unsigned int i = 0; i < point.size(); i++ )
		moveLine[i]->set( point[i], addVector( point[i], *moveVector ), true );

}

//**************************************************************************
//�f�o�b�N�p
//VECTOR2D : �J�������W�n�̌��_
//**************************************************************************
#ifdef _DEBUG
void CCollision::debug( VECTOR2D revise ){

	//for print
	for( unsigned int i = 0; i < point.size(); i++ ){

		//DrawCircle( point[i].x-revise.x, point[i].y-revise.y, 2, GetColor( 255, 0, 0 ), 1 );
		moveLine[i]->debug( revise );

	}

}
#endif
