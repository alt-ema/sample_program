/**************************************************************************/
/*�X�e�[�W1�N���X                                                         */
/**************************************************************************/

#include "stage.h"
#include "object.h"
#include "player.h"

//**************************************************************************
//�I�u�W�F�N�g�̈ړ�����
//list< CObject* >* : �I�u�W�F�N�g���X�g
//**************************************************************************
void CStage::moveManager( list< CObject* > objectList ){

	list< CObject* >::iterator it = objectList.begin();

	while( it != objectList.end() ){

		(*it)->move();
		it++;

	}

}

//**************************************************************************
//�����蔻�萧��
//list< CObject* >* : �I�u�W�F�N�g���X�g
//**************************************************************************
void CStage::rejectManager( list< CObject* > objectList, list< CObject* > rejectList ){

	list< CObject* >::iterator it = objectList.begin();

	while( it != objectList.end() ){

		(*it)->reject( rejectList );
		it++;

	}

}

//**************************************************************************
//�I�u�W�F�N�g�̍��W�X�V
//list< CObject* >* : �I�u�W�F�N�g���X�g
//**************************************************************************
void CStage::updateManager( list< CObject* > objectList ){

	list< CObject* >::iterator it = objectList.begin();

	while( it != objectList.end() ){

		(*it)->update();
		it++;

	}

}

//**************************************************************************
//�I�u�W�F�N�g�̏�������(�_���[�W�A�o���letc)
//list< CObject* >* : �I�u�W�F�N�g���X�g
//**************************************************************************
void CStage::runManager( list< CObject* > objectList ){

	list< CObject* >::iterator it = objectList.begin();

	while( it != objectList.end() ){

		(*it)->run();
		it++;

	}

}

//**************************************************************************
//�I�u�W�F�N�g�̕`�搧��
//list< CObject* >* : �I�u�W�F�N�g���X�g
//**************************************************************************
void CStage::drawManager( list< CObject* > objectList, VECTOR2D vec ){

	list< CObject* >::iterator it = objectList.begin();

	while( it != objectList.end() ){

		(*it)->draw( vec );
		it++;

	}

}

//**************************************************************************
//�I�u�W�F�N�g�̃f�o�b�O����
//list< CObject* >* : �I�u�W�F�N�g���X�g
//**************************************************************************
#ifdef _DEBUG
void CStage::debugManager( list< CObject* > objectList, VECTOR2D vec ){

	list< CObject* >::iterator it = objectList.begin();

	while( it != objectList.end() ){

		(*it)->debug( vec );
		it++;

	}

}
#endif

//**************************************************************************
//2015/7/27 ����
//**************************************************************************
void CStage::camera(){

	//init
	if( timer == 0 ){

		cameraVector = player->getPlayerPoint();
		cameraVector.add( -WINDOW_X/2, -WINDOW_Y/2 );

	}

	//calc x
	cameraVector.x = player->getPlayerPoint().x - WINDOW_X/2;

	//calc y
	if( cameraVector.y + 100 > player->getPlayerPoint().y ){

		cameraVector.y = player->getPlayerPoint().y;
		cameraVector.add( 0, -100 );

	}else if( cameraVector.y + WINDOW_Y - 100 < player->getPlayerPoint().y ){

		cameraVector.y = player->getPlayerPoint().y;
		cameraVector.add( 0, -(WINDOW_Y - 100) );

	}

}

//**************************************************************************
//�o�ߎ��Ԃ̎Z�o(�� : �b : �~���b)
//**************************************************************************
void CStage::calcTimer(){

	DrawFormatString( 100, 585, GetColor( 255, 255, 255 ), "%d : %d : %d",
		timer / 3600,
		(timer / 60) % 60,
		timer % 60 );		//�~���b�͏C������

	timer++;

}
