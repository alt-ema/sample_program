/**************************************************************************/
/*���ʃN���X�̒�`                                                        */
/**************************************************************************/

#include <Windows.h>
#include "game.h"
#include "stage_manager.h"
//#include "start_manager.h"
//#include "practice_manager.h"
//#include "replay_manager.h"
//#include "gallery_manager.h"
//#include "option_manager.h"

#pragma comment(lib, "winmm.lib")

#ifdef _DEBUG
#include "stage1.h"
//#include "line.h"
//#include "collision.h"
//#include "rejection.h"
//#include "block.h"
#endif

//**************************************************************************
//�O���[�o���ϐ�
//**************************************************************************
int inputKey[MAX_PAD];			//�L�[����
int releaseKey[MAX_PAD];		//�L�[����

//**************************************************************************
//�Q�[���R���X�g���N�^
//int    : �E�B���h�E����
//int    : �E�B���h�E�c��
//int    : �t���X�N���[�� or �E�B���h�E
//string : �E�B���h�E�e�L�X�g
//**************************************************************************
CGame::CGame( int x, int y, int window, char* window_text )
:	gameTimer(0),
	gameState(0),
	dwLastFlipped(0),
	dwErrorValue(0)
{
	//window text
	SetMainWindowText( window_text );
	//window size
	SetGraphMode( x, y, 32 );

#ifndef _DEBUG
	//�E�B���h�E or �t���X�N���[��
	( window == IDNO ) ? ChangeWindowMode(TRUE) : ChangeWindowMode(FALSE);	
#else //�f�o�b�N���[�h�̏ꍇ��ɃE�B���h�E���[�h�ŋN������
	ChangeWindowMode(TRUE);
#endif

	//�O���[�o���ϐ��̏�����
	memset( inputKey, 0, sizeof( inputKey ) );
	memset( releaseKey, 0, sizeof( releaseKey ) );
}

//**************************************************************************
//�Q�[���̎��s
//**************************************************************************
void CGame::run(){

	getKey( inputKey, releaseKey );

	stage->run();

	/*
	// TODO
	//�Q�[���{�̂̏���(�A�N�V�����Q�[��)
	switch( gameState ){

		case GAME_START:

			break;

		case GAME_PRACTICE:

			break;

		case GAME_GALLERY:

			break;

		case GAME_OPTION:

			break;

		case GAME_EXIT:

			break;

		default:

			break;

	}
	// ======
	*/

	//��������
	wait( 50 );

	//calcTimer
	gameTimer++;

#ifdef _DEBUG
	debug();
#endif

}

//**************************************************************************
//���\�[�X���蓖��
//**************************************************************************
void CGame::format(){

	//gameStage = new CStageManager();
	//gameStart = new CStartManager();
	//gamePractice = new CPracticeManager();
	//gameReplay = new CReplayManager();
	//gameGallery = new CGalleryManager();
	//gameOption = new COptionManager();

	//debug
	stage = new CStage1();

}

//**************************************************************************
//����������
//DWORD : 60fps�̏ꍇ50�Œ�(16.66... * 3)
//**************************************************************************
void CGame::wait( DWORD j ){ //�o�O�L

	DWORD dw,dw2;

	while( j > (dw2 = ((dw = timeGetTime()) - dwLastFlipped) * 3 + dwErrorValue) )
		Sleep(1);
	
    int i;
    static int t = 0, f[30];
    static double ave = 0;
 
    f[gameTimer%30] = (dw2 / 3);
    
    if( gameTimer%30 == 29 ){

        ave = 0;

        for( i=0; i<30; i++ )
            ave += f[i];

        ave /= 30;

    }

    if( ave != 0 )
        DrawFormatString( 0, 585, GetColor( 255, 255, 255 ), "%.2f", 1000/(double)ave );
    
	dwLastFlipped = dw;
	dwErrorValue = dw2 % j;

}

//**************************************************************************
//�Q�[�����[�v(��{�����͂�����Ȃ�)
//**************************************************************************
int CGame::loop(){

	if( ProcessMessage() != 0 ) return -1;
	if( ClearDrawScreen() != 0 ) return -1;
	return 0;

}

//**************************************************************************
//�f�o�b�O�p
//**************************************************************************
#ifdef _DEBUG
void CGame::debug(){

	DrawFormatString( 0, 0, GetColor( 255, 255, 255 ),
		"inputKey[0] = %d, inputKey[1] = %d", inputKey[0], inputKey[1] );
	DrawFormatString( 0, 15, GetColor( 255, 255, 255 ),
		"inputKey[2] = %d, inputKey[3] = %d", inputKey[2], inputKey[3] );
	DrawFormatString( 0, 30, GetColor( 255, 255, 255 ),
		"inputKey[4] = %d, inputKey[5] = %d", inputKey[4], inputKey[5] );
	DrawFormatString( 0, 45, GetColor( 255, 255, 255 ),
		"inputKey[6] = %d, inputKey[7] = %d", inputKey[6], inputKey[7] );

	DrawFormatString( 0, 60, GetColor( 255, 255, 255 ),
		"releaseKey[0] = %d, releaseKey[1] = %d", releaseKey[0], releaseKey[1] );
	DrawFormatString( 0, 75, GetColor( 255, 255, 255 ),
		"releaseKey[2] = %d, releaseKey[3] = %d", releaseKey[2], releaseKey[3] );
	DrawFormatString( 0, 90, GetColor( 255, 255, 255 ),
		"releaseKey[4] = %d, releaseKey[5] = %d", releaseKey[4], releaseKey[5] );
	DrawFormatString( 0, 105, GetColor( 255, 255, 255 ),
		"releaseKey[6] = %d, releaseKey[7] = %d", releaseKey[6], releaseKey[7] );

}
#endif
